#pragma once
#include "../../NuklearDefinition.h"

void WarningPopup(struct nk_context* ctx, int* func, boolean* featureState, boolean* popupState);