#pragma once
#include "../../NuklearDefinition.h"

void ShowTriggerTab(struct nk_context* ctx, int* triggerBot, int* teamCheck, PFeaturesStates Features, PConfig config);