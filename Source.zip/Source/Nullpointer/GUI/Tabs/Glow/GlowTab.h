#pragma once
#include "../../NuklearDefinition.h"
#include "../WarningPopup/WarningPopup.h"

void ShowGlowTab(struct nk_context* ctx, int* wallhack, PFeaturesStates Features, PGUIConfig conf);