#pragma once
#include "../../NuklearDefinition.h"
#include "../WarningPopup/WarningPopup.h"

void ShowAimTab(struct nk_context* ctx, int* aimbot, int* fov, PFeaturesStates Features, PConfig config, PGUIConfig gconf);
