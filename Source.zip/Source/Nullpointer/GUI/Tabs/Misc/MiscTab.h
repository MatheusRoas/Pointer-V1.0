#pragma once
#include "../../NuklearDefinition.h"
#include "../WarningPopup/WarningPopup.h"

void ShowMiscTab(struct nk_context* ctx, int* antiFlash, int* radar, PFeaturesStates Features, PConfig config);