#pragma once
#include "../../NuklearDefinition.h"

void ShowESPTab(struct nk_context* ctx, int* espTeamCheckState, int* line, int* box, int* health, PFeaturesStates Features, PGUIConfig conf);