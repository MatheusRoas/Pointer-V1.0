#pragma once
#include "../NuklearDefinition.h"

void apply_9ght_style(struct nk_context* ctx);