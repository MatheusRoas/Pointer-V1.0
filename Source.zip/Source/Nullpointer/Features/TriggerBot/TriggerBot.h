#pragma once
#include "../../dependencies.h"
#include "../Entity/Entity.h"

void _TriggerBot(PEntity localPlayer, UINT8* triggerEntityTeam, int* flags, PFeaturesStates featuresPointer, PConfig data);