#pragma once
#include "../../dependencies.h"

void _Glow(PHANDLE driver, uintptr_t currentPawn, int color);