#pragma once
#include "../../dependencies.h"

void _AntiFlash(PHANDLE driver, uintptr_t localPlayer);