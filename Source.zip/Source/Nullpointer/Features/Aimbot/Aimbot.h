#pragma once
#include "../../dependencies.h"

void AimAtTarget(PEntity player, float distance, PFeaturesStates featuresPointer, PConfig data);